import tkinter
from tkinter import *
from tkinter import ttk, messagebox
import pickle
import numpy as np

# Load Model and Vectorizer
model = pickle.load(open("C:\\Users\\S.Deepika\\OneDrive\\Desktop\\python notes\\SMSSpam\\model.pkl", "rb"))
cv = pickle.load(open("C:\\Users\\S.Deepika\\OneDrive\\Desktop\\python notes\\SMSSpam\\vector.pkl", "rb"))

# Func to Check Msg
def result_msg():
    user_input = entry.get("1.0", END).strip()  
    if user_input == "":
        messagebox.showwarning("Warning", "Please enter a message to check!")
        return  

    # Convert inp txt to num form
    message = np.array([user_input])  
    message = cv.transform(message)  
    pred = model.predict(message)[0]  

    # Result
    if pred == 1:
        result_label.config(text="Spam Message 🚨", fg="red", bg="white")
    else:
        result_label.config(text="Not Spam ✅", fg="green", bg="white")

# Root Window
root = Tk()
root.geometry("500x400")
root.title("Spam Detector")
root.resizable(False, False)

# GUI Setup
title_label = Label(root, text="Spam Message Detector", font=("Arial", 16, "bold"), bg="#4CAF50", fg="white", pady=10)
title_label.pack(fill=X)


entry = Text(root, height=10, width=50, font=("Arial", 12))
entry.pack(pady=10)

check_button = Button(root, text="Check", font=("Arial", 12, "bold"), bg="#2196F3", fg="white", command=result_msg)
check_button.pack(pady=5)

result_label = Label(root, text="", font=("Arial", 14, "bold"), bg="#f0f0f0")
result_label.pack(pady=10)

root.mainloop()
