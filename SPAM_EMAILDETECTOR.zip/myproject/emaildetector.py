import tkinter as tk
from tkinter import messagebox
import pickle
from sklearn.feature_extraction.text import CountVectorizer

def load_model():
    try:
        with open("model.pkl", "rb") as model_file:
            model = pickle.load(model_file)
        with open("vector.pkl", "rb") as vector_file:
            vectorizer = pickle.load(vector_file)
        return model, vectorizer
    except Exception as e:
        messagebox.showerror("Error", f"Failed to load model: {e}")
        return None, None

def classify_email():
    email_text = entry.get("1.0", tk.END).strip()
    if not email_text:
        messagebox.showwarning("Input Error", "Please enter an email message.")
        return
    
    email_vector = vectorizer.transform([email_text])
    prediction = model.predict(email_vector)[0]
    result_label.config(text="❌ This email is SPAM"
                        if prediction == 1 
                        else "✅ This email is NOT spam", fg="red"
                        if prediction == 1 
                        else "green")

# Load Model
model, vectorizer = load_model()

# GUI Setup
root = tk.Tk()
root.title("Email Spam Detector")
root.geometry("500x400")
root.configure(bg="#f0f0f0")

title_label = tk.Label(root, text="Email Spam Detector", font=("Arial", 16, "bold"), bg="#4CAF50", fg="white", pady=10)
title_label.pack(fill=tk.X)

entry = tk.Text(root, height=10, width=50, font=("Arial", 12))
entry.pack(pady=10)

check_button = tk.Button(root, text="Check", font=("Arial", 12, "bold"), bg="#2196F3", fg="white", command=classify_email)
check_button.pack(pady=5)

result_label = tk.Label(root, text="", font=("Arial", 14, "bold"), bg="#f0f0f0")
result_label.pack(pady=10)

root.mainloop()
