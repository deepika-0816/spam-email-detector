import pandas as pd
import numpy as np
import re
import nltk
import pickle
from nltk.corpus import stopwords
from nltk.stem import SnowballStemmer
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score

# Download nltk
nltk.download('stopwords')

# Load
dataset = pd.read_csv("C:\\Users\\S.Deepika\\OneDrive\\Desktop\\python notes\\SMSSpam\\myproject\\spamemail.csv", encoding="latin1")

# Rename col
dataset.rename(columns={'Category': 'Label', 'Message': 'Message'}, inplace=True)

# "spam" =1 and "ham"= 0
dataset['Label'] = dataset['Label'].map({'ham': 0, 'spam': 1})

# Text Preprocessing
stemmer = SnowballStemmer(language="english")
corpus = []
for message in dataset['Message']:
    message = re.sub('[^a-zA-Z]', ' ', message)  # Remove special characters
    message = message.lower()  # Convert to lowercase
    message = message.split()  # Tokenization
    message = [stemmer.stem(word) for word in message if word not in stopwords.words('english')]
    corpus.append(' '.join(message))

# Convert text into numerical data using CountVectorizer
cv = CountVectorizer()
X = cv.fit_transform(corpus).toarray()

y = dataset['Label'].values

# Split the data
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model
classifier = MultinomialNB()
classifier.fit(x_train, y_train)

# Evaluate the model
y_pred = classifier.predict(x_test)
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred))
print("Recall:", recall_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))

# Load saved model & vectorizer
with open("model.pkl", "rb") as model_file:
    model = pickle.load(model_file)

with open("vector.pkl", "rb") as vector_file:
    cv = pickle.load(vector_file)

# Test with a new email
new_email = ["Congratulations! You have won a free iPhone. Claim now."]
new_email_vectorized = cv.transform(new_email).toarray()

# Predict
prediction = model.predict(new_email_vectorized)

# Display Result
if prediction[0] == 1:
    print("❌ This email is SPAM!")
else:
    print("✅ This email is NOT spam.")


print("Model and vectorizer saved successfully!")